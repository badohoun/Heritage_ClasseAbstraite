from setuptools import setup

setup(
    name='packaging',
    version='0.0.0',
    packages=['packaging'],
    #specify the package metadata
    author='Espoir BADOHOUN',
    author_email = 'your_email@example.com',
    description='A simple package for packaging',
    license='MIT',
)