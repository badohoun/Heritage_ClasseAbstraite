from my_other_file import CONSTANT 
from my_folder.my_nested_file import CONSTANT as CONSTANT2
from my_folder import A 

print(CONSTANT)
print(CONSTANT2)